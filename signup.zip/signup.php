<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class signup extends Controller
{

    function signup(Request $request){
       print_r($request->all());
        return view('signup');
    }
}
