<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spotify-Your favourite music is here</title>
    <!-- js file for fontawesome -->
    <script src="https://kit.fontawesome.com/fb46d810ca.js"crossorigin="anonymous"></script>
    <!-- favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="https://i.pinimg.com/originals/c0/67/8f/c0678f89e06d785a701b75d2d901e3e4.png"/>
    

    <style>
       @import url('https://fonts.googleapis.com/css2?family=Ubuntu&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Varela+Round&display=swap');
body{
    background-color: antiquewhite;
}

*{
    margin: 0;
    padding: 0;
}

nav{
    font-family: 'Ubuntu', sans-serif;
}

nav ul{
    display: flex;
    align-items: center;
    list-style-type: none;
    height: 65px;
    background-color: black;
    color: white;
}

nav ul li{
    padding: 0 12px;
}
nav ul li a{
  color:white;
  text-decoration:none;
}
nav ul li a:hover{
  color:red;
  border-bottom: 1px solid white;
  transition: red 1s ease-in-out infinite alternate;
}
.brand img{
    width: 44px;
    padding: 0 8px;
}

.brand {
    display: flex;
    align-items: center;
    font-weight: bolder;
    font-size: 1.3rem;
}

#card{
  display:flex;
  flex-direction:row;
  height:fit-content;
  width:fit-content;
  background-color:transparent;
  margin:2% 3%;
  align-items: space-around;
  /* justify-content:center; */
}
.inner-card{
  border-radius:10px;
  background-color:white;
  width:fit-content;
  height:100%;
  box-shadow:5px 10px 10px 10px grey;
  margin:1% 2%;
}
.bg-img-top{
  border-radius:10px;
}
.artist-name{
 text-transform:uppercase;
 text-decoration:underline;
 padding-left:1%;
}
.title{
  font-size:15px;
  text-transform:uppercase;
  padding-left:1%
}

.album-name{
  text-transform:uppercase;
  color:dodgerblue;
  font-size:20px;
  font-weight:bold;
  
}
.album-name:hover{
  color:red;
}
/* @keyframes zoom-in-zoom-out{
  0%{
    font-size:15px;
  }
  50%{
    font-size:25px;
  }
  100%{
    font-size:30px;
  }
} */
@keyframes change_color{
  0%{
    color:black;
    text-shadow:5px 5px 5px white;
  }
  25%{
    color: red;
    text-shadow:5px 5px 5px yellow;
  }
  50%{
    color:green;
    text-shadow:5px 5px 5px orange;
  }
  100%{
    color:dodgerblue;
    text-shadow:5px 5px 5px pink;
  }
}
#heading{
  font-size:40px;
  text-align:center;
  text-transform:capitalize;
  animation:change_color 1s ease-in-out infinite alternate;
  /* animation:zoom-in-zoom-out 1s ease-in-out infinite alternate; */
}

/* --------------MaiSection: Social Section---------------- */

#social {
  position: fixed;
  top: 20%;
  left: 0;
  line-height: 1;
  background-color:transparent;
}

#social .social-btn {
  display: block;
  padding: 14px 13px;
  color: black;
  border-bottom:1px solid transparent;
}
#social .social-icon{
  font-size:1.2rem;
}

@keyframes big{
   0%{
     font-size:1.2rem;
   }
   50%{
     font-size:1.4rem;
   }
   100%{
     font-size:1.6rem;
   }
}
.social-icon:hover{
  animation:big 1s ease-in-out infinite alternate;
}
#social .social-btn:hover{
  border-bottom:1px solid rgb(136, 127, 127);
  transition:1s ease-in-out;
}
.social-btn .fa-brands.fa-facebook-square:hover{
  color:rgb(6, 108, 167);
  transition:1s ease-in-out;
}
.social-btn .fa-brands.fa-linkedin:hover{
  color:rgb(4, 255, 242);
  transition:1s ease-in-out;
}
.social-btn .fa-brands.fa-twitter-square:hover{
  color:rgb(1, 114, 148);
  transition:1s ease-in-out;
}
.social-btn .fa-solid.fa-envelope:hover{
  color:rgb(253, 5, 5);
  transition:1s ease-in-out;
}
.social-btn .fa-brands.fa-whatsapp-square:hover{
  color:rgb(5, 97, 5);
  transition:1s ease-in-out;
}
    </style>
    

</head>
<body>

<!-- Navigation Bar -->
<nav>
        <ul>
            <li class="brand"><img src="https://i.pinimg.com/originals/03/2b/08/032b0870b9053a191b67dc8c3f340345.gif" alt="Spotify"> Spotify</li>            
            <li><a href="/index">Home</a></li>
            <li><a href="/playlist">Playlist</a></li>
            <li><a href="/signup">Sign Up</a></li>
        </ul>
</nav>

     <!-- main page -->
     <h1 id="heading">popular artist album</h1>
      <div id="card">
        <div class="inner-card">
          <img src="https://i.pinimg.com/originals/44/4b/41/444b418488926f2c673253df5f46d34c.jpg" alt="arijit singh" class="bg-img-top" height="200" width="300">
          <br><h3 class="artist-name">arijit singh</h3>
          <br><span class="title">click here to see <a href="/album" class="album-name">album</a></span>
        </div>
        <div class="inner-card">
          <img src="https://wallpaperaccess.com/full/6386209.jpg" alt="Lata Mangeshkar" height="200" width="300" class="bg-img-top">
          <br><h3 class="artist-name">Lata Mangeshkar</h3>
          <br><span class="title">click here to see <a href="/album" class="album-name">album</a></span>
        </div>
        <div class="inner-card">
          <img src="https://wallpaperaccess.com/full/4268776.jpg" alt="Kumar Sanu"  height="200" width="300" class="bg-img-top">
          <br><h3 class="artist-name">Kumar Sanu</h3>
          <br><span class="title">click here to see <a href="/album" class="album-name">album</a></span>
        </div>
        <div class="inner-card">
          <img src="https://wallpapercave.com/wp/wp5411397.jpg" alt="palak muchhal"  height="200" width="300" class="bg-img-top">
          <br><h3 class="artist-name">Palak Munchhal</h3>
          <br><span class="title">click here to see <a href="/album" class="album-name">album</a></span>
        </div>
      </div>
      <div id="card">
        <div class="inner-card">
          <img src="https://wallpaperaccess.com/full/3703702.jpg" class="bg-img-top" height="200" width="300">
          <br><h3 class="artist-name">Alka Yagnik</h3>
          <br><span class="title">click here to see <a href="/album" class="album-name">album</a></span>
        </div>
        <div class="inner-card">
          <img src="https://www.bollywoodhungama.com/wp-content/uploads/2020/08/EXCLUSIVE-Rahul-Jain-reveals-that-he-wrote-Bepannaah%E2%80%99s-title-track-while-travelling.jpeg" class="bg-img-top" height="200" width="300">
          <br><h3 class="artist-name">Rahul Jain</h3>
          <br><span class="title">click here to see <a href="/album" class="album-name">album</a></span>
        </div>
        <div class="inner-card">
          <img src="https://wallpaperaccess.com/full/2012326.jpg" alt="Neha Kakkar" height="200" width="300" class="bg-img-top">
          <br><h3 class="artist-name">Neha kakkar</h3>
          <br><span class="title">click here to see <a href="/album" class="album-name">album</a></span>
        </div>
        <div class="inner-card">
          <img src="https://yt3.ggpht.com/ytc/AKedOLSY1ZOhQ8E1XAQbnZwZ2hLUQQEPj8Q7YXgIy9q8=s900-c-k-c0x00ffffff-no-rj" alt="Udit Narayan" height="200" width="300" class="bg-img-top">
          <br><h3 class="artist-name">Udit Narayan</h3>
          <br><span class="title">click here to see <a href="/album" class="album-name">album</a></span>
        </div>
      </div>

    <!-- footer section -->
    <!--------------------Social media section--------------------------->
    <div id="social">
              <a  class="social-btn" target="_blank" href="http://www.facebook.com/sharer.php?u=http%3A%2F%2Fblog.codingninjas.in%2F2018%2F03%2F13%2Fa-step-by-step-walk-through-of-your-first-html-page%2F"><i class="fa-brands fa-facebook-square social-icon"></i></a>
  
              <a  class="social-btn" target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&title=Best+Coding+Practices+for+Hassle-free+Programming&url=http%3A%2F%2Fblog.codingninjas.in%2F2018%2F04%2F02%2Fbest-coding-practices-for-hassle-free-programming%2F"><i class="fa-brands fa-linkedin social-icon"></i></a>
  
              <a  class="social-btn" target="_blank" href="https://twitter.com/share?url=http%3A%2F%2Fblog.codingninjas.in%2F2018%2F04%2F02%2Fbest-coding-practices-for-hassle-free-programming%2F&text=Best+Coding+Practices+for+Hassle-free+Programming"><i class="fa-brands fa-twitter-square social-icon"></i></a>
  
              <a  class="social-btn" target="_blank" href="https://plus.google.com/share?url=http%3A%2F%2Fblog.codingninjas.in%2F2018%2F04%2F02%2Fbest-coding-practices-for-hassle-free-programming%2F"><i class="fa-solid fa-envelope social-icon"></i></a>
  
              <a  class="social-btn" target="_blank" href="whatsapp://send?text=http%3A%2F%2Fblog.codingninjas.in%2F2018%2F04%2F02%2Fbest-coding-practices-for-hassle-free-programming%2F"><i class="fa-brands fa-whatsapp-square social-icon"></i></a>  
          </div>
     

</body>
</html>