<link rel="stylesheet" href="css/style.css">
<style>
    #form{
        border:1px solid black;
        border-radius:10px;
        height:fit-content;
        width:30%;
        background-color:grey;
        margin:2% 40%;
    }
    form{
        padding:2% 5%;
    }
    label{
        color: white;
        font-size:20px;
        text-tranform:capitalize;
    }
    p{
        color: white;
        font-size:20px;
        text-tranform:capitalize;
    }
    input[type=email]{
      padding:5px 10px;
      width:70%;
      background-color:lightgrey;
      color:black;
      border-radius:10px;
    }
    input[type=password]{
     padding:5px 10px;
      width:70%;
      border-radius:10px;
    }
    input[type=text]{
        padding:5px 10px;
      width:70%;
      background-color:lightgrey;
      color:black;
      border-radius:10px;
    }
    input[type=submit]{
        border:1px solid black;
        padding:1% 3%;
        background-color:green;
        color:black;
        font-size:15px;
        border-radius:10px;
        margin-left:40%;
    }
    </style>
<nav>
        <ul>
            <li class="brand"><img src="https://i.pinimg.com/originals/03/2b/08/032b0870b9053a191b67dc8c3f340345.gif" alt="Spotify"> Spotify</li>            
            <li><a href="/index">Home</a></li>
            <li><a href="/playlist">Playlist</a></li>
            <li><a href="/signup">Sign Up</a></li>
        </ul>
    </nav>
    
<div id="form">
    <form action="" method="post">
       @csrf

       <label for="email">What's your email?</label><br>
       <input type="email" id="email" name="email1"><br><br>

       <label for="email">Confirm your email</label><br>
       <input type="email" id="email" name="email"><br><br>

       <label for="password">Create a Password</label><br>
       <input type="password" id="password" name="password" placeholder="Enter your Pwd"><br><br>

       <label for="pname">What should we call You?</label><br>
       <input type="text" id="pname" name="pname" placeholde="Enter a profile name"><br>
       <p>This appears on your profile</p><br>

       <label for="birthday">Date Of Birth</label><br>
       <input type="date" id="birthday" name="birthday"><br><br>

       <label for="gender">What's Your gender?</label><br>
       <input type="radio" name="gender" id="male" value="male">
       <label for="gender">Male</label><br>
       <input type="radio" name="gender" id="female" value="female">
       <label for="gender">Female</label><br>
       <input type="radio" name="gender" id="non-binary" value="non-binary">
       <label for="gender">Non-binary</label><br>


  <p>Please select your age:</p>
  <input type="radio" id="age1" name="age" value="25">
  <label for="age1">15 - 25</label><br>
  <input type="radio" id="age2" name="age" value="40">
  <label for="age2">26 - 40</label><br>  
  <input type="radio" id="age3" name="age" value="70">
  <label for="age3">41 - 70</label><br><br>


  <input type="submit" value="Sign Up">




    </form>
</div>