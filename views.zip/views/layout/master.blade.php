<!DOCTYPE html>
<html lang="en">
<head>
       <title>@yield('title')
           {{--@yield title will show the title of header. --}}
    </title>
</head>
<body>
    @yield('content')
    {{-- @yield-content will show the content of all the element inside the header --}}
    <header>
    <a href="/home">Home</a>
    <a href="/contactus">Contact us</a>
    <a href="/signup">Sign up</a>
    </header>
</body>
</html>