<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spotify-Your favourite music is here</title>

    <!-- favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="https://i.pinimg.com/originals/c0/67/8f/c0678f89e06d785a701b75d2d901e3e4.png"/>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Navigation Bar -->
    <nav>
        <ul>
            <li class="brand"><img src="https://i.pinimg.com/originals/03/2b/08/032b0870b9053a191b67dc8c3f340345.gif" alt="Spotify"> Spotify</li>            
            <li><a href="/index">Home</a></li>
            <li><a href="/playlist">Playlist</a></li>
            <li><a href="/signup">Sign Up</a></li>
            
        </ul>
    </nav>

    <!-- Main section code -->

    <h1 id="heading">Latest Releases Song</h1>

    <div class="container">
        <div class="songList">
            <div class="songItemContainer">
                <div class="songItem">
                    <img alt="1">
                    <span class="songName">Let me Love You</span>
                    <span class="songlistplay"><span class="timestamp">05:34 <i id="0" class="far songItemPlay fa-play-circle"></i> </span></span>
                </div>
                <div class="songItem">
                    <img alt="1">
                    <span class="songName">Let me Love You</span>
                    <span class="songlistplay"><span class="timestamp">05:34 <i id="1" class="far songItemPlay fa-play-circle"></i> </span></span>
                </div>
                <div class="songItem">
                    <img alt="1">
                    <span class="songName">Let me Love You</span>
                    <span class="songlistplay"><span class="timestamp">05:34 <i id="2" class="far songItemPlay fa-play-circle"></i> </span></span>
                </div>
                <div class="songItem">
                    <img alt="1">
                    <span class="songName">Let me Love You</span>
                    <span class="songlistplay"><span class="timestamp">05:34 <i id="3" class="far songItemPlay fa-play-circle"></i> </span></span>
                </div>
                <div class="songItem">
                    <img alt="1">
                    <span class="songName">Let me Love You</span>
                    <span class="songlistplay"><span class="timestamp">05:34 <i id="4" class="far songItemPlay fa-play-circle"></i> </span></span>
                </div>
                <div class="songItem">
                    <img alt="1">
                    <span class="songName">Let me Love You</span>
                    <span class="songlistplay"><span class="timestamp">05:34 <i id="5" class="far songItemPlay fa-play-circle"></i> </span></span>
                </div>
                <div class="songItem">
                    <img alt="1">
                    <span class="songName">Let me Love You</span>
                    <span class="songlistplay"><span class="timestamp">05:34 <i id="6" class="far songItemPlay fa-play-circle"></i> </span></span>
                </div>
                <div class="songItem">
                    <img alt="1">
                    <span class="songName">Let me Love You</span>
                    <span class="songlistplay"><span class="timestamp">05:34 <i id="7" class="far songItemPlay fa-play-circle"></i> </span></span>
                </div>
                <div class="songItem">
                    <img alt="1">
                    <span class="songName">Let me Love You</span>
                    <span class="songlistplay"><span class="timestamp">05:34 <i id="8" class="far songItemPlay fa-play-circle"></i> </span></span>
                </div>
                <div class="songItem">
                    <img alt="1">
                    <span class="songName">Let me Love You</span>
                    <span class="songlistplay"><span class="timestamp">05:34 <i id="9" class="far songItemPlay fa-play-circle"></i> </span></span>
                </div>
            </div>
        </div>
        <div class="songBanner"></div>
    </div>

    <h1 id="heading">Latest Hindi Song</h1>
    <div id="outer-container">
        <div class="inner-container">
            <img src="https://freerangestock.com/sample/52618/music-background-meaning-singing-instruments-and-notes-.jpg" 
            class="bg-img" alt="" height="60" width="70">
            <span class="title-song">Taare Zameen par</span>
            &emsp;&emsp;&emsp;&ensp;<audio controls class="audio" >
            <source src="songs/4.mp3" type="audio/mpeg"></source>
            </audio>
        </div>
        <div class="inner-container">
            <img src="https://api.time.com/wp-content/uploads/2019/09/karaoke-mic.jpg?quality=85&w=1200&h=628&crop=1" class="bg-img" alt="" height="60" width="70">
            <span class="title-song">Raanjhna</span>
            &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<audio controls class="audio" >
            <source src="songs/4.mp3" type="audio/mpeg"></source>
            </audio>
        </div>
        <div class="inner-container">
            <img src="https://media.self.com/photos/5e70f72443731c000882cfe7/4:3/w_2560%2Cc_limit/GettyImages-125112134.jpg" class="bg-img" alt="" height="60" width="70">
            <span class="title-song">Tu kitni Achhi hain</span>
            &emsp;&emsp; <audio controls class="audio" >
            <source src="songs/4.mp3" type="audio/mpeg"></source>
            </audio>
        </div>
        <div class="inner-container">
            <img src="https://images.theconversation.com/files/179797/original/file-20170726-14517-sc2a8r.jpg?ixlib=rb-1.1.0&q=45&auto=format&w=1200&h=900.0&fit=crop" class="bg-img" alt="" height="60" width="70">
            <span class="title-song">Ye un dino ki baat hain</span>
            <audio controls class="audio" >
            <source src="songs/4.mp3" type="audio/mpeg"></source>
            </audio>
        </div>
        <div class="inner-container">
            <img src="https://wallpaperaccess.com/full/1891192.jpg" class="bg-img" alt="" height="60" width="70">
            <span class="title-song">Dil Tujhko chahe</span>
            &emsp;&emsp;&emsp;&emsp;<audio controls class="audio" >
            <source src="songs/4.mp3" type="audio/mpeg"></source>
            </audio>
        </div class="inner-container">
    </div>

<!-- footer page -->
<div class="bottom">
        <input type="range" name="range" id="myProgressBar"  min="0" value="0" max="100">
        <div class="icons">
            <!-- fontawesome icons -->
            <i class="fas fa-3x fa-step-backward" id="previous"></i>
            <i class="far fa-3x fa-play-circle" id="masterPlay"></i>
            <i class="fas fa-3x fa-step-forward" id="next"></i> 
        </div>
        <div class="songInfo">
            <img src="../image/playing.gif" width="42px" alt="" id="gif"> <span id="masterSongName">Warriyo - Mortals [NCS Release]</span>
        </div>
    </div>

<script src="js/myscript.js"></script>
 <!-- code for fonts -->
 <script src="https://kit.fontawesome.com/26504e4a1f.js" crossorigin="anonymous"></script>
</body>
</html>