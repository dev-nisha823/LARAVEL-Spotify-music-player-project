@extends('layout.master')
@section('title','Contact us')
@section('content')

<h1>This is the Contact page.</h1>

@endsection