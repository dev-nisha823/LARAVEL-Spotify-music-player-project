<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- js file for fontawesome -->
    <script src="https://kit.fontawesome.com/fb46d810ca.js"crossorigin="anonymous"></script>
    <!-- favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="https://i.pinimg.com/originals/c0/67/8f/c0678f89e06d785a701b75d2d901e3e4.png"/>
    <title>Index page</title>
    <style>
     
     /* ----------Header section-------------NAVIGATION  BAR----------------------------- */
  #navbar{
    position:relative; 
    display:flex;
  }
  #navbar::before{
           content: "";
           background-color:#6d6d6e;
           position:absolute;
           height:90%;
           width:100%;
           opacity:0.4;
           z-index: -1;
  } 

  /* navigationbar logo and image */
#logo{
  background-color:transparent;
  height:fit-content;
}
#logo img {
  border-radius: 50%;
  text-align:center;
  padding:20px 10px;
}
/* navbar brand name */
.navbar-brand{
  padding:20px 1px;
  display:inline-block;
  text-align:center;
  text-decoration:none;
  color:var(--navbar-text-color);
  font-family: var(--navbar-fontfamily);
}

  /*navigation bar list styling*/

  #navbar ul{
    list-style:none;
    display:flex;
    margin-left:100px;
  }
  #navbar ul li{
    padding:20px 20px;
  }
  #navbar ul li{
    padding:20px 20px;
  }
  /* navbar favourite-button */
  #favourite-button{
       border:1px solid transparent;
       border-radius:2px;
       padding:5px 10px;
       cursor:pointer;
       font-size:1.2rem;
       box-shadow: 5px 5px 10px 5px rgb(128, 124, 124);
       font-family:var(--navbar-fontfamily);
       background-image:linear-gradient(to top left,rgb(252, 1, 1),white,rgb(90, 90, 92));
  }
  select{
    border:1px solid transparent;
    background-color:transparent;
  }
  select option{
    background-color: #f0f0f7;
    color:black;
  }

  /* navbar upgrade-button */
  #upgrade-button{
       border:1px solid transparent;
       border-radius:20px;
       padding:5px 20px ;
       font-size:1rem;
       color:white;
       box-shadow: 5px 5px 10px 5px rgb(185, 176, 176);
       font-family:var(--navbar-fontfamily);
       background-color: black;
  }
  #upgrade-button:hover{
    color:Red;
    border:1px groove red;
  }
/* navbar search button */
#search-button {
  padding: 8px 10px;
  background-color: #b4b3ba;
  border: 1px solid transparent;
  border-radius: 20px;
}
.search {
  margin: 2px;
  padding: 5px;
  color: blue;
  background-color: aquamarine;
  border-radius: 10px;
  border: 1px groove black;
}
.fa-solid.fa-magnifying-glass {
  cursor: pointer;
  font-size: 1rem;
}
.search:hover {
  background-color: transparent;
  border: 1px solid transparent;
  color: black;
}
/* navbar notification styling */
.fa-solid.fa-bell {
  margin-top: 10px;
  font-size: 1.5rem;
  border-radius:50%;
  background-color:red;
  padding:4px 4px;
}
.fa-solid.fa-bell:hover {
  cursor: pointer; 
}

/* Navigation bar profile image styling */
.profile-dropdown .profile-dropimg {
  color: white;
  font-size: 16px;
  border: none;
  cursor: pointer;
  border-radius:50%;
}
.profile-dropdown {
  position: relative;
  display: inline-block;
}
.profile-dropdown-content {
  display: none;
  position: absolute;
  background-color: lightcyan;
  min-width: 200px;
  min-height:200px;
  box-shadow: 0px 8px 16px 0px rgb(12, 12, 12);
  z-index: 1;
}
.profile-dropdown-content .profile-a {
  color: black;
  text-decoration: none;
  display: block;
  padding:15px 16px;
  border-bottom:1px solid rgb(59, 57, 57);
  
}
.profile-dropdown-content .profile-a:hover {background-color: dodgerblue;
 color:white;
 transition:1s ease-in-out;
}
.profile-dropdown:hover .profile-dropdown-content {
  display: block;

}

    </style>
</head>
<body>
    




@extends('layout.master')
@section('title','Home')
@section('content')

{{--<!--------------------------Header Section--------------------->--}}
   {{-- <!----------Navigation Bar------------->--}}
    <nav id="navbar">
     {{-- <!-- Logo image -->--}}
      <div id="logo">
         <img src="https://i.pinimg.com/originals/03/2b/08/032b0870b9053a191b67dc8c3f340345.gif" height="50" width="50"
           alt="logo_image"/>
     </div>
               {{--<!-- navbar-brand name -->--}}
     <a class="navbar-brand" href="#">Album <br> Studio</a>
      {{--<!-- navbar section  -->--}}
      <ul>
          {{--<!--navbar favourite-button-->--}}
          <li>
            <button type="button" id="favourite-button">
             <select value="Favourite">
              <option><i class="fa-solid fa-users"></i>Favourite</option>
              <option><i class="fa-solid fa-users"></i>Artist</option>
              <option><i class="fa-solid fa-language"></i>Language</option>
              <option><i class="fa-solid fa-headphones"></i>Song</option>
            </select>
          </button>
          </li>
          {{--<!-- Navbar upgrade-button -->--}}
          <li>
            <a href="login"><button type="button" id="upgrade-button" title="Upgrade to Premium">UPGRADE</button></a>
          </li>
          {{--<!-- navbar search-button -->--}}
          <li>
            <button type="button" id="search-button">
              <i class="fa-solid fa-magnifying-glass"></i>
              <input type="search" placeholder="Search..." class="search" />
              <i class="fa-solid fa-microphone-lines microphone"></i>
            </button>
          </li>
          {{--<!-- navbar notification -->--}}
          <li>
            <i class="fa-solid fa-bell" style="color:var(--navbar-text-color);"></i>
          </li>
          {{--<!-- navbar Profile-section -->--}}
          <li>
            <div class="profile-dropdown">
              <img src="http://thumbs.xdesktopwallpapers.com/wp-content/uploads/2012/04/Sad%20Cartoon%20Girl%20Listning%20Music-720x405.jpg" 
                          alt="profile-image" height="50" width="50" class="profile-dropimg">
              <div class="profile-dropdown-content">
              <a href="#" class="profile-a"><span>&emsp;&emsp;&emsp;&emsp;&ensp;<i class="fa-solid fa-square-xmark"></i></span></a>
              <a href="#" class="profile-a"><span><i class="fa-solid fa-user"></i></span>&ensp;Profile</a>
              <a href="#" class="profile-a"><span><i class="fa-solid fa-headphones-simple"></i></span>&ensp;Playlist</a>
              <a href="#" class="profile-a"><span><i class="fa-solid fa-music"></i></span>&ensp;favourite_Song</a>
              <a href="#" class="profile-a"><span><i class="fa-solid fa-gear"></i></span>&ensp;Setting</a>
              <a href="#" class="profile-a"><span><i class="fa-solid fa-arrow-right-from-bracket"></i></span>&ensp;Logout</a>
              </div>
            </div>
          </li>
        </ul>
    </nav>

@endsection



</body>
</html>