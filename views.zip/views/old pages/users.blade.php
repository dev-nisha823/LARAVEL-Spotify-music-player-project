<style>
    span{
        color:red;
    }
</style>

<h1>Upgrade to Premium</h1>

{{--@if($errors->any())
@foreach($errors->all() as $err)
<li>{{$err}}</li>
@endforeach
@endif--}}

{{--@if($errors->any())
<h4>{{$errors->first()}}</h4>
@endif--}}

<span>@error('username'){{$message}}@enderror</span>
<form action="users" method="post">
@csrf {{--to secure our code--}}
Username:&emsp;&emsp;&emsp;&ensp;<input type="text" name="username" placeholder="enter user id"/>
<br>
<span>@error('password'){{$message}}@enderror</span>
<br>Password:&emsp;&emsp;&emsp;&ensp;&nbsp;<input type="password" placeholder="enter password" name="userpassword"/>
<br>
<label for="email">Enter your email:</label>
&ensp;<input type="email" id="email" name="email"> 
<br>
<h3>Already a member</h3>
<button type="button">Login</button>
<br>
<h3>Don't have an account?</h3>
<button type="button">Sign Up</button><br>
<button type="submit">Submit</button>

</form>