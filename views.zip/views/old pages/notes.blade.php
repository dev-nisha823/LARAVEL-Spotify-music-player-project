<!-- step 1: open cmd
step 2: write command "php artisan make:controller user" , here user is controller name u can name it of your choice 
step 3: now again open cmd and write php artisan serve
step 4: open that controller which you have created successfully in your code editor
step 5: in user.php you will fine a class in line 7, inside the class write
function index(){
    echo "hello world";
}

step 6: copy 3rd line of user.php "namespace App\Http\Controllers\user;" and paste it in web.php on the top of it
and replace the word 'namespace' with 'use'.
step 7: in the bottom of web.php write this command "Route::get("/hello",[user::class,"index"]);"
-->

<!-- HOW TO WRITE if statement IN LARAVEL 
@if  //starting 
@endif    // ending 

but if we want to write another statement in between these two if statement then we will write like this
@if 

@elseif

@else

@endif

-->

<!-- SWITCH STATEMENT

switch($i)
  @case(1)
    First case.....
    @break

  @case(2)
    Second case....
    @break

  @default
    Default case....
@endswitch
-->


<!-- to check current laravel version install in system or not 
 php artisan --version
-->

<!-- to write comment in laravel we will write like this
{{----}}
-->

<!-- interpolation of variable in laravel done using {{}}  
 -->

 <!-- @unless($i)
      unless is an inverse of if
       html code 
      @endunless -->



<!-- bootstrap directory in laravel is used to initialise a laravel application -->

<!-- .ENV file is used to set the database connection in Laravel. -->

<!-- if we want to write for loop in our code then we have to comment all the previous code to get the output of for loop. -->


<!-- QUERY  PARAMETER:
  whatever query we will search it comes after ? 

if we want to display our query parameter on web page then we have to
step1: write in the route page

-->


<!-- 
Template Inheritance:
Layout: we will use the masterpage in every page using layout in laravel

blade template inheritance means to inherit one page from another page.


// these are called as directives.
@yield: use it in masterpage (we will get the input from child page- retrieve the infmn)
@yield and @section work parallel.
@section: use it in main/index page (we will send the data to child-display the infmn) 

@extends:
-->

<!-- {{$errors}}  to show pop up messages when we have not fill the form and submitted it -->


