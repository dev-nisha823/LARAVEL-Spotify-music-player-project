<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css" type="text/css">
    <style>
    body{
     background-image:url("../image/LPU.jpg");
     height:65vh;
     opacity:0.8;
     background-position: center;
     background-size: cover;
     /* background-attachment: fixed; */
        }
    header{
            background-image:repeating-linear-gradient(to top right, orange,white,green);
            margin:0;
            padding:0;
            box-shadow:5px 5px 5px white;
        }
    #heading1{
       text-align:Center;
       font-family:sans-serif;
       margin:auto;
       font-family:timesnewroman;
    }
    ul li {
        list-style: none;
        color:lightslategray;
    } 
    li a{
        text-decoration:none;
        text-transform:uppercase;
        color:black;
        float:left;
        padding:10px 10px;
        text-align:center;
        /* font-size:10px; */
    }
    li a:hover{
        color:lightgrey;
        transition:1s ease-in-out;
    }

    </style>
</head>
<body>
    <header>
      <H1 id="heading1">Welcome to LOVELY PROFESSIONAL UNIVERSITY</H1>
      <ul>
          <li><a href="#">parents login</a></li>
          <li><a href="#">jobs</a></li>
          <li><a href="#">happenings</a></li>
          <li><a href="#">conferences</a></li>
          <li><a href="#">study abroad</a></li>
          <li><a href="#">lpunest</a></li>
          <li><a href="#">int.admissions</a></li>
          <li><a href="#">online education</a></li>
          <li><a href="#">distance education</a></li>
          <li><a href="#">contact us</a></li>
      </ul>
    </header>



    {{-- 
        
        interpolation sign{{}} --}}
<!-- 
{{--{{$student_name}} has taken the addmission in {{$university_name}} in {{$branch}} branch.


@switch($branch)
    @case($branch="CSE")
        <p>{{$student_name}} has taken admission in branch CSE</p>
        @break
 
    @case($branch!="CSE")
    <p>{{$student_name}} has taken admission in other branch</p>
        @break
 
    @default
    <p>{{$student_name}} has not taken admission in LPU</p>
@endswitch  --}} -->
</body>
</html>