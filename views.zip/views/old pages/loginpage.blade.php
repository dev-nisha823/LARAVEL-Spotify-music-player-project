<link rel="stylesheet" href="css/style.css">
<nav>
        <ul>
            <li class="brand"><img src="https://i.pinimg.com/originals/03/2b/08/032b0870b9053a191b67dc8c3f340345.gif" alt="Spotify"> Spotify</li>            
            <li><a href="/index">Home</a></li>
            <li><a href="/playlist">Playlist</a></li>
            <li><a href="/signup">Sign Up</a></li>
            <li><a href="/login">Login</a></li>
        </ul>
    </nav>

    <form action="" method="post">
        @csrf
        <label for="email">Email:</label><br>
        <input type="email" name="email" id="email"><br><br>

        <label for="password">Enter Password</label><br>
        <input type="password" name="password" id="password"><br><br>
        <input type="submit" value="Login">
    </form>