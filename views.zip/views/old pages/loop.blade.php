<h1>FOR LOOP</h1>

<!-- code for query parameter -->
{{$name}} course offer is {{$code}} off

{{--{{$product_name}} with brand {{$product_brand}}
price is {{$product_price}} having {{$product_color}}

<!-- @for($i=0;$i<=5;$i++)
<P>This is for product{{$i}}</p>
@endfor -->

<!-- count is used to count the product  -->


<!-- 
@for($i=0;$i<count($loop);$i++)
{{
    $loop[$i]['product_name']
}}
@endfor --> 

@foreach ($flower as $product_color)
    <p>This is user {{ $user->id }}</p>
@endforeach
--}}

