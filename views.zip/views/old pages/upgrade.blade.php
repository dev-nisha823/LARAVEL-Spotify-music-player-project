<link rel="stylesheet" href="css/style.css">
<nav>
        <ul>
            <li class="brand"><img src="https://i.pinimg.com/originals/03/2b/08/032b0870b9053a191b67dc8c3f340345.gif" alt="Spotify"> Spotify</li>            
            <li><a href="/index">Home</a></li>
            <li><a href="/playlist">Playlist</a></li>
            <li><a href="/signup">Sign Up</a></li>
            <li><a href="/upgrade">UPGRADE</a></li>
            <li><a href="/login">Login</a></li>
        </ul>
    </nav>