<h1>Here this page is acquainted with all info of products 
{{--{{ $n }} {{ $b}}--}}
</h1>


{{$name}} with brand {{$brand}}
price is {{$price}}

{{-- if statement--}}
@if($price<25000)
<p>Product is cheap</p>
@endif

{{-- if elseif statement--}}
@if($price<25000)
<p>Product is cheap</p>
@elseif($price>25000 && $price<50000)
<p>Product is at normal rate</p>
@else
<p>Product is costlier</p>
@endif


{{-- switch statement--}}
@switch($price)
@case($price<25000)
<p>Price is cheap</p>
@break

@case($price>25000 && $price<50000)
<p>Price is normal</p>
@break
@default
<p>Price is costlier</p>
@endswitch


@unless($brand=="hp")
<p>Product is of new brand collaborated with HP</p>
@endunless