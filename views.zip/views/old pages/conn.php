<?php
    // Create connection
	$conn = new mysqli("localhost", "root", "", "form");
	
    // Check connection
	if(!$conn){
		die("Error: Cannot connect to the database");
	}
?>