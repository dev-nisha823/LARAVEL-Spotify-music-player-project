<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\nisha;
use App\Http\Controllers\userscontroller;
use App\Http\Controllers\signup;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/test', function () {
//     return view('welcome');
// });
// //we use .blade.php because it is a template engine we use in laravel to open web page
// // routing using get method
// // Route::get('/first', function () { 
// //     return view('first');
// // });
// // Route::get('/second', function () {
// //     return view('second');
// // });
// // Route::get('/third', function () {
// //     return view('third');
// // });
// // if we will write test instead of first,second,third then last one will be executed.
// // routing using view method.
// Route::view('first','first');// alternative route
// Route::view('second','second');
// // How to provide ID in URL and print that id in web page
// Route::get('/first/{id}', function ($id) {
//     echo $id;
//     return view('first');
// });

// Route::get('/index', function () {
//     return view('index');
// });


Route::get('/first/{id}', function ($id) {
        echo $id;
       return view('first');
    });
Route::view('index','index');// alternative route
Route::view('home','home');
Route::view('about_us','about_us');
Route::view('signup','signup');
Route::view('register','register');
Route::view('feedback','feedback');
Route::view('create five links','create five links');

// how to call the controller;

Route::get("/hello",[user::class,'index']);
Route::get("/hello1",[nisha::class,'index']);
Route::get('/first/{id}', function ($id) {
        echo $id;
       return view('first');
    });
Route::get("/hello2/{id?}",[nisha::class,'index']);



// userscontroller page code:
// Route::post("users",[userscontroller::class,'getData']);
// Route::view("login","users");
//how to get any page through controller


Route::get('/view', function () {
    return view('view');
    });

// how to call any folder through controller
    Route::get('/view', function () {
        return view('myfolder.header.view.footer');
        });


// Product page code:
Route::get('/product', function() {
	$product=["name"=>"Laptop","brand"=>"asus","price"=>23000];
      return view('product',$product);

});

// Loop code
Route::get('/loop', function() {
	$product=[
    ["product_name"=>"Mobile","product_brand"=>"Redme","product_price"=>18000,"product_color"=>"silver"],
    ["product_name"=>"Tablet","product_brand"=>"Huwaei","product_price"=>30000,"product_color"=>"black"]
];
      return view('loop',['loop'=>$product]);

});

// UNIVERSITY page code
// Route::get('/university', function() {
// 	$university=["student_name"=>"Harry","university_name"=>"LPU","branch"=>"CSE"];
//       return view('university',$university);

// });

Route::get('/university', function () {
      return view('university');
});

// for query parameter :
Route::get('/loop',function()
{
 $name=request('n');
 $code=request('c');
 return view('loop',['name'=>$name,'code'=>$code]);
});

// write this in tab after the file name of webpage n=laravel&c=34%



// code of Project - Music player :-

Route::get('/home',function(){
     return view('index');
});

Route::get('/playlist',function(){
    return view('playlist');
});

Route::get('/album',function(){
    return view('album');
});

Route::post('/signup',[signup::class,'signup']);

